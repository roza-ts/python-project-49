### Hexlet tests and linter status:
[![Actions Status](https://github.com/roza-ts/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/roza-ts/python-project-49/actions)
<a href="https://codeclimate.com/github/roza-ts/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c1ab604d790f810019cb/maintainability" /></a>

[![asciicast](https://asciinema.org/a/5kHXulGFpOldRltIfnJz4JxLx.svg)](https://asciinema.org/a/5kHXulGFpOldRltIfnJz4JxLx)

[![asciicast](https://asciinema.org/a/547624.svg)](https://asciinema.org/a/547624)

[![asciicast](https://asciinema.org/a/547763.svg)](https://asciinema.org/a/547763)

[![asciicast](https://asciinema.org/a/547764.svg)](https://asciinema.org/a/547764)

[![asciicast](https://asciinema.org/a/547765.svg)](https://asciinema.org/a/547765)
