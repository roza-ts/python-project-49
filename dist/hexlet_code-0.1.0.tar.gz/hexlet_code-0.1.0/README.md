### Hexlet tests and linter status:
[![Actions Status](https://github.com/roza-ts/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/roza-ts/python-project-49/actions)
<a href="https://codeclimate.com/github/roza-ts/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c1ab604d790f810019cb/maintainability" /></a>

[![asciicast](https://asciinema.org/a/BTtFP4FIBnaDwg683VnB1aRzC.svg)](https://asciinema.org/a/BTtFP4FIBnaDwg683VnB1aRzC)
