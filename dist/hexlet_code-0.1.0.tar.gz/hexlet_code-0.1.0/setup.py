# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '## Hexlet tests and linter status:\n[![Actions Status](https://github.com/RozaTsy/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/RozaTsy/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/28d06e7d3f8c06b2c7a1/maintainability)](https://codeclimate.com/github/RozaTsy/python-project-49/maintainability)\n\n[![asciicast](https://asciinema.org/a/5kHXulGFpOldRltIfnJz4JxLx.svg)](https://asciinema.org/a/5kHXulGFpOldRltIfnJz4JxLx)\n\n[![asciicast](https://asciinema.org/a/547624.svg)](https://asciinema.org/a/547624)\n',
    'author': 'RozaTsy',
    'author_email': 'ayara2015@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
